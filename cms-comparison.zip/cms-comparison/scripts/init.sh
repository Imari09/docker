#!/bin/bash

echo "=== Инициализация среды сравнения CMS ==="

# Создание структуры папок
mkdir -p {nginx/{conf.d,vhost.d,html,certs},grav/{data,config,pages,plugins,themes},jekyll/{site,_site},wordpress/{wp-content,uploads,db},shared-data/{content,images,translations},scripts}

# Копирование конфигурационных файлов
cp nginx-default.conf nginx/conf.d/default.conf

# Создание демо-данных
echo "Создание единых демо-данных..."

# Для Grav
cat > shared-data/content/home.md << EOF
---
title: 'Тестовая служба IT-поддержки'
visible: true
---

# Добро пожаловать в тестовую службу поддержки

Это демонстрационный сайт для сравнения CMS. Здесь отображаются тестовые данные по инцидентам IT-поддержки.

## Наши услуги:
1. Устранение неполадок ПО
2. Настройка оборудования  
3. Консультации по безопасности
EOF

# Для Jekyll
cat > shared-data/content/index.md << EOF
---
layout: home
title: "Тестовая служба IT-поддержки"
---

# Добро пожаловать в тестовую службу поддержки

Это демонстрационный сайт для сравнения CMS. Здесь отображаются тестовые данные по инцидентам IT-поддержки.

## Наши услуги:
1. Устранение неполадок ПО
2. Настройка оборудования
3. Консультации по безопасности
EOF

# Создание инцидентов
for i in {1..3}; do
  cat > shared-data/content/incident-$i.md << EOF
---
title: "Инцидент #00$i"
date: "2024-01-${i}5"
category: "Устранение неполадок ПО"
status: "Решен"
---

**Описание проблемы:** Тестовый инцидент #$i
**Решение:** Тестовое решение #$i
**Статус:** Решен
EOF
done

echo "Установка прав доступа..."
chmod -R 755 scripts
chmod -R 775 shared-data

echo "=== Инициализация завершена ==="
echo "Запустите: docker-compose up -d"