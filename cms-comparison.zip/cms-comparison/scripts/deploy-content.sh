#!/bin/bash

echo "=== Деплой единого контента во все CMS ==="

# Копирование в Grav
echo "Копирование в Grav..."
cp -r shared-data/content/* grav/pages/
cp -r shared-data/images/* grav/data/images/

# Копирование в Jekyll
echo "Копирование в Jekyll..."
cp shared-data/content/index.md jekyll/site/
mkdir -p jekyll/site/_posts
for file in shared-data/content/incident-*.md; do
  if [ -f "$file" ]; then
    # Преобразуем для Jekyll (_posts/YYYY-MM-DD-title.md)
    date=$(grep -oP 'date: "\K[^"]+' "$file" | head -1)
    title=$(grep -oP 'title: "\K[^"]+' "$file" | head -1 | tr ' ' '-' | tr -cd '[:alnum:]-')
    newname="${date}-${title}.md"
    cp "$file" "jekyll/site/_posts/$newname"
  fi
done

# Копирование в WordPress (через базу данных)
echo "Для WordPress импорт через XML или вручную в админке"
echo "Создан файл для импорта: shared-data/wordpress-import.xml"

# Создание файла импорта для WordPress
cat > shared-data/wordpress-import.xml << EOF
<?xml version="1.0" encoding="UTF-8"?>
<rss>
  <channel>
    <title>Тестовая служба поддержки</title>
    <item>
      <title>Инцидент #001</title>
      <content:encoded><![CDATA[**Описание проблемы:** Тестовый инцидент #1]]></content:encoded>
      <category>Устранение неполадок ПО</category>
    </item>
  </channel>
</rss>
EOF

echo "=== Деплой завершен ==="
echo "Перезапустите контейнеры: docker-compose restart"